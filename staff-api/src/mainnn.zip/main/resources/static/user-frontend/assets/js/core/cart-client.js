
// --- BEGIN PATCH: namespaced local cart + events ---
function getAnonId(){
  try {
    let id = localStorage.getItem('fs_anon_id');
    if(!id){
      id = (crypto && crypto.randomUUID) ? crypto.randomUUID() : (Date.now() + '-' + Math.floor(Math.random()*1e6));
      localStorage.setItem('fs_anon_id', id);
    }
    return id;
  } catch(e){
    return 'anon';
  }
}
function localCartKey(userId){
  if(userId) return `fs_cart_user_${userId}`;
  return `fs_cart_guest_${getAnonId()}`;
}
function readLocalCart(userId){
  try { return JSON.parse(localStorage.getItem(localCartKey(userId)) || '[]'); } catch(e){ return []; }
}
function writeLocalCart(items, userId){
  try { localStorage.setItem(localCartKey(userId), JSON.stringify(items || [])); } catch(e){}
  window.dispatchEvent(new CustomEvent('cart:updated', { detail: { userId: userId||null, items: items || [] }}));
}
function removeGuestCart(){
  try { localStorage.removeItem(localCartKey(null)); } catch(e){}
}
// --- END PATCH ---

// assets/js/core/cart-client.js (patched)
(() => {
  const API = (window.FS_API || 'http://localhost:9090');
  const LS_KEYS = ['fs_cart','cart','shopping_cart','cartItems'];

  const token = () => {
    try { return localStorage.getItem('fs_token') || sessionStorage.getItem('fs_token') || ''; }
    catch { return ''; }
  };
  const emit  = (type, detail)=>window.dispatchEvent(new CustomEvent(type,{detail}));
  const toInt = v => Math.max(1, Number(v)||1);

  const parseJSON = s => { try{return JSON.parse(s);}catch{return null;} };

  function normalizeItem(it){
    if(!it) return null;
    const p   = it.product || it.variant || {};
    const id  = it.id || it.skuId || it.sku || it.variantId || it.productId || p.id || null;
    const sku = it.sku || it.skuId || it.variantCode || p.sku || id;
    const name = it.name || it.productName || p.name || 'Sản phẩm';
    const price = Number(it.price ?? it.unitPrice ?? it.unit_price ?? p.price ?? 0) || 0;
    const qty   = Math.max(1, Number(it.qty ?? it.quantity ?? it.count ?? 1));
    const imageUrl = it.imageUrl || it.image || it.thumbnail || p.imageUrl || p.image || 'assets/img/placeholder.png';
    return { id, sku, name, price, qty, imageUrl, total: price*qty };
  }
  const normalizeList = arr => (arr||[]).map(normalizeItem).filter(Boolean);

  function readLocal(){
    const all = [];
    for(const store of [localStorage, sessionStorage]){
      for(const k of LS_KEYS){
        try{
          const raw = store.getItem(k); if(!raw) continue;
          const v = parseJSON(raw);
          if(Array.isArray(v)) all.push(...v);
          else if(v && Array.isArray(v.items)) all.push(...v.items);
          else if(v && Array.isArray(v.lines)) all.push(...v.lines);
        }catch{}
      }
    }
    return normalizeList(all);
  }

  function writeLocal(lines){
    const clean = normalizeList(lines);
    try{
      localStorage.setItem(localCartKey(null), JSON.stringify(clean));
      // cleanup các key cũ để tránh xung đột hiển thị
      for(const k of LS_KEYS) if(k!=='fs_cart'){ localStorage.removeItem(k); sessionStorage.removeItem(k); }
    }catch{}
    return clean;
  }

  function mergeLocal(line){
    const list = readLocal();
    const key  = String(line.sku || line.id);
    const i    = list.findIndex(x => String(x.sku||x.id) === key);
    if(i>=0){
      list[i].qty   = Math.min(999, (list[i].qty||0) + (line.qty||1));
      list[i].total = list[i].qty * (list[i].price||0);
    }else{
      list.push(line);
    }
    return writeLocal(list);
  }

  function clearLocal(){
    try{ localStorage.removeItem('fs_cart'); }catch{}
    refreshBadge();
  }

  function refreshBadge(){
    const n = document.querySelector('.badge-cart'); if(!n) return;
    const count = readLocal().reduce((s,x)=> s + (x.qty||0), 0);
    n.textContent = count > 0 ? `Giỏ hàng (${count})` : 'Giỏ hàng';
  }

  // helper: build items payload for merge endpoint
  function buildMergePayload(list){
    return { items: (list||[]).map(i=>({ skuId: Number(i.sku||i.id), sku_id: Number(i.sku||i.id), qty: Number(i.qty||1), quantity: Number(i.qty||1) })) };
  }

  // Try to add item via several possible server endpoints
  async function apiAddItem(skuOrId, qty){
    const t = token();
    const headersBase = { 'Content-Type':'application/json', 'Accept':'application/json' };

    const payloadA = { skuId: Number(skuOrId), qty: Number(qty), sku_id: Number(skuOrId), quantity: Number(qty) };
    const bodyA = JSON.stringify(payloadA);
    const bodyB = JSON.stringify({ sku: skuOrId, quantity: qty }); // fallback style some servers expect

    const tries = [
      { url:'/api/cart/items',          method:'POST', body: bodyA },
      { url:'/api/cart',                method:'POST', body: bodyA },
      { url:'/api/user/cart/items',     method:'POST', body: bodyA },
      { url:'/api/cart-items',          method:'POST', body: bodyA },
      { url:'/api/cart/items',          method:'POST', body: bodyB } // last try alternate format
    ];

    // If token present, use Authorization header. Always set credentials: 'include' so cookie session works too.
    for(const tr of tries){
      try{
        const headers = Object.assign({}, headersBase);
        if(t) headers['Authorization'] = 'Bearer ' + t;

        const opts = { method: tr.method, headers, credentials: 'include', body: tr.body };

        console.debug('[cart] trying', opts.method, API+tr.url, 'hasToken=', !!t, 'body=', tr.body);
        const r = await fetch(API + tr.url, opts);

        if(r.ok){
          try{ const j = await r.json(); console.debug('[cart] success', r.status, API+tr.url, j); return { ok:true, body:j }; }catch{ console.debug('[cart] success no-json', r.status, API+tr.url); return { ok:true, body:null }; }
        }

        // nếu server trả lỗi, log status + body (text/json) để tiện debug
        let txt;
        try { txt = await r.text(); } catch(e){ txt = '<no body>'; }
        console.warn(`[cart] API ${tr.method} ${API+tr.url} returned ${r.status}:`, txt);
      }catch(err){
        console.warn('[cart] fetch error for', API+tr.url, err);
      }
    }
    return { ok:false };
  }

  async function handleAdd(btn){
    const skuOrId = (btn.dataset.sku || btn.dataset.id || '').trim();
    const name    = btn.dataset.name  || 'Sản phẩm';
    const price   = Number(btn.dataset.price || 0) || 0;
    const qtyEl   = btn.dataset.qtyEl ? document.querySelector(btn.dataset.qtyEl) : null;
    const qty     = toInt(qtyEl?.value || btn.dataset.qty || 1);
    const imageUrl= btn.dataset.image || 'assets/img/placeholder.png';

    if(!skuOrId){ console.warn('[cart] Missing sku/id on button'); return; }

    // Đã đăng nhập (hoặc có token) → ưu tiên API
    const t = token();
    if(t){
      try{
        const res = await apiAddItem(skuOrId, qty);
        if(res.ok){
          // if server responded with updated cart DTO, you could update localstore accordingly
          // but still keep a local mirror for offline
          mergeLocal({ id: skuOrId, sku: skuOrId, name, price, qty, imageUrl });
          emit('cart:changed', { source:'api', skuOrId, qty });
          refreshBadge();
          return;
        }else{
          console.warn('[cart] apiAddItem returned ok:false -> fallback to local');
        }
      }catch(err){
        console.warn('[cart] apiAddItem threw -> fallback to local', err);
      }
    } else {
      // Try cookie-based API even if token absent (maybe server uses cookie session)
      try {
        const res = await apiAddItem(skuOrId, qty);
        if(res.ok){
          mergeLocal({ id: skuOrId, sku: skuOrId, name, price, qty, imageUrl });
          emit('cart:changed', { source:'api-cookie', skuOrId, qty });
          refreshBadge();
          return;
        } else {
          console.debug('[cart] apiAddItem with cookie also failed -> fallback local');
        }
      } catch(e) {
        console.warn('[cart] apiAddItem cookie attempt error', e);
      }
    }

    // Ẩn danh / API fail → local
    mergeLocal({ id: skuOrId, sku: skuOrId, name, price, qty, imageUrl });
    emit('cart:changed', { source:'local', skuOrId, qty });
    refreshBadge();
  }

  // Sync local cart to server after login (try token first; else try with credentials)
  async function syncLocalCartToServer(){
    const local = readLocal();
    if(!local || local.length === 0) return null;

    const payload = buildMergePayload(local);
    const t = token();

    // First try with token (if available)
    if(t){
      try{
        console.debug('[cart] merging local -> server using token', payload);
        const r = await fetch(API + '/api/cart/merge', {
          method: 'POST',
          headers: { 'Content-Type':'application/json', 'Accept':'application/json', 'Authorization':'Bearer ' + t },
          credentials: 'include',
          body: JSON.stringify(payload)
        });
        if(r.ok){
          const json = await r.json();
          clearLocal();
          emit('cart:merged', { serverCart: json });
          return json;
        } else {
          const txt = await r.text(); console.warn('[cart] merge failed (token)', r.status, txt);
        }
      }catch(err){ console.warn('[cart] merge error (token)', err); }
    }

    // Fallback: try with cookie credentials (in case server uses session cookie)
    try{
      console.debug('[cart] merging local -> server using cookie credentials', payload);
      const r2 = await fetch(API + '/api/cart/merge', {
        method: 'POST',
        headers: { 'Content-Type':'application/json', 'Accept':'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      if(r2.ok){
        const json = await r2.json();
        clearLocal();
        emit('cart:merged', { serverCart: json });
        return json;
      } else {
        const txt = await r2.text(); console.warn('[cart] merge failed (cookie)', r2.status, txt);
      }
    }catch(err){ console.warn('[cart] merge error (cookie)', err); }

    return null;
  }

  function bind(){
    const btns = Array.from(document.querySelectorAll('.btn-add-cart,[data-action="add-to-cart"],#addBtn'));
    btns.forEach(btn=>{
      // avoid double binding
      if(btn.__cart_bound) return;
      btn.__cart_bound = true;

      btn.addEventListener('click', (e)=>{
        // prevent navigation / form submit
        if(e && e.preventDefault) e.preventDefault();
        // safe call
        handleAdd(btn);
      }, { passive:false });
    });
    // refresh badge lúc vào trang
    refreshBadge();

    // if user already logged in, attempt to sync local cart -> server
    if(token()){
      // fire and forget, update badge after
      syncLocalCartToServer().then(()=> refreshBadge());
    } else {
      // even if no token, try cookie-based merge in background (helps when server uses cookie session)
      // but run this only if cookies exist for site
      if(document.cookie && document.cookie.length>0){
        syncLocalCartToServer().then(()=> refreshBadge());
      }
    }
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bind);
  }else{
    bind();
  }

  // public (nếu cần dùng nơi khác)
  window.FS_CART = { addFromButton: handleAdd, refreshBadge, readLocal, writeLocal, syncLocalCartToServer, apiAddItem };
})();


// Ensure any direct writes to old fs_cart also trigger event - monkey patch (fallback)
(function(){
  const originalSet = Storage.prototype.setItem;
  Storage.prototype.setItem = function(k, v){
    try {
      if(k && k.indexOf('fs_cart')!==-1){
        // do nothing special, we'll keep namespaced writes via helper; still emit event
        originalSet.apply(this, [k, v]);
        try { window.dispatchEvent(new CustomEvent('cart:updated', { detail: { key: k }})); } catch(e){}
        return;
      }
    } catch(e){}
    originalSet.apply(this, [k, v]);
  };
})();
