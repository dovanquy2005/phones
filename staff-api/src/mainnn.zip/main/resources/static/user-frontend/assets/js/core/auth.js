// assets/js/auth.js (ESM)
const API = 'http://localhost:9090';

export function getToken() {
  try { return localStorage.getItem('fs_token') || sessionStorage.getItem('fs_token') || ''; }
  catch { return ''; }
}

function normalizeUser(me = {}) {
  let roles = [];
  if (Array.isArray(me.roles) && me.roles.length) roles = me.roles;
  else if (typeof me.role === 'string' && me.role) roles = [me.role];
  else roles = ['user'];
  return {
    id: me.id || me.userId || null,
    name: me.name || me.fullName || me.username || 'User',
    email: me.email || null,
    roles
  };
}


export async function getCurrentUser() {
  const token = getToken();
  if (!token) return null;

  try {
    const r = await fetch(`${API}/api/auth/me`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    });

    if (!r.ok) return null;

    const data = await r.json().catch(() => null);
    const me = (data && (data.user || data)) || null;

    // Lưu bản chuẩn hoá vào localStorage để menu đọc ra ngay
    if (me) {
      try {
        localStorage.setItem('fs_user', JSON.stringify(normalizeUser(me)));
      } catch {}
      // Emit event để các module khác (badge, header, cart) biết auth đã sẵn sàng
      try {
        // auth:ready cho các module lắng nghe (ví dụ: cart-badge)
        window.dispatchEvent(new Event('auth:ready'));
        // auth:login cho các module cụ thể (nếu cần)
        window.dispatchEvent(new Event('auth:login'));
      } catch (e) { /* ignore */ }
    }

    // Trả về object gốc từ BE (giữ nguyên field để các nơi khác dùng)
    return me;
  } catch (e) {
    console.error('getCurrentUser error', e);
    return null;
  }
}

function clearLocalCartAndHelpers(){
  const KEYS = ['fs_cart','cart','shopping_cart','cartItems','fs_uid','auth_user','fs_user'];
  for(const k of KEYS){
    try { localStorage.removeItem(k); sessionStorage.removeItem(k); } catch(e){/*ignore*/ }
  }
  // báo cho các module khác — badge sẽ nhận và cập nhật
  try {
    window.dispatchEvent(new CustomEvent('cart:changed', { detail: { count: 0, source: 'logout' } }));
  } catch (e) { /* ignore */ }
}

export async function doLogout({ clearGuestCart = true } = {}) {
  try {
    // best-effort notify server
    await fetch(`${API}/api/auth/logout`, { method: 'POST' });
  } catch {}

  try {
    // remove tokens + user info
    localStorage.removeItem('fs_token'); localStorage.removeItem('fs_user');
    sessionStorage.removeItem('fs_token'); sessionStorage.removeItem('fs_user');
  } catch {}

  // If you want to remove guest cart on logout (recommended), do it
  if (clearGuestCart) {
    clearLocalCartAndHelpers();
  } else {
    // still notify modules that logout happened so badge can refresh from local guest storage
    try { window.dispatchEvent(new Event('auth:logout')); } catch(_) {}
    try { window.dispatchEvent(new CustomEvent('cart:changed', { detail: { source: 'logout' } })); } catch(_) {}
  }

  // Redirect after a tiny delay to allow listeners to react (optional)
  setTimeout(() => { location.href = 'login.html'; }, 20);
}
