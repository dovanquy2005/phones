package com.fonestore.user_api.controller;

import com.fonestore.user_api.dto.cart.*;
import com.fonestore.user_api.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

/**
 * CartController: endpoints accept optional query param userId.
 * If not provided, attempt to resolve userId from SecurityContext (JWT auth).
 */
@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cart;

    /** Helper: if userId param missing, resolve from security principal (set by JwtAuthFilter). */
    private Long resolveUserId(Long userId) {
        if (userId != null) return userId;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return null;
        Object principal = auth.getPrincipal();
        if (principal instanceof Long) return (Long) principal;
        if (principal instanceof String) {
            try { return Long.valueOf((String) principal); } catch (NumberFormatException ignored) {}
        }
        // principal might be a Map/Claims — try common cases:
        try {
            // if principal has "id" field (e.g. Map), reflection/handles can be added here
            // but keep simple for most setups
        } catch (Exception ignored) {}
        return null;
    }

    @GetMapping
    public ResponseEntity<CartDTO> getCart(@RequestParam(required = false) Long userId) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.getCart(uid));
    }

    @PostMapping("/items")
    public ResponseEntity<CartDTO> addItem(@RequestParam(required = false) Long userId,
                                           @RequestBody @Valid AddItemRequest req) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.addItem(uid, req));
    }

    @PutMapping("/items/{itemId}")
    public ResponseEntity<CartDTO> updateItem(@RequestParam(required = false) Long userId,
                                              @PathVariable Long itemId,
                                              @RequestBody @Valid UpdateItemRequest req) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        UpdateItemRequest newReq = new UpdateItemRequest(itemId, req.qty());
        return ResponseEntity.ok(cart.updateItem(uid, newReq));
    }

    @DeleteMapping("/items/{itemId}")
    public ResponseEntity<CartDTO> removeItem(@RequestParam(required = false) Long userId,
                                              @PathVariable Long itemId) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.removeItem(uid, itemId));
    }

    @PostMapping("/clear")
    public ResponseEntity<CartDTO> clear(@RequestParam(required = false) Long userId) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.clear(uid));
    }

    @PostMapping("/checkout")
    public ResponseEntity<CartDTO> checkout(@RequestParam(required = false) Long userId) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.checkout(uid));
    }

    @PostMapping("/merge")
    public ResponseEntity<CartDTO> merge(@RequestParam(required = false) Long userId,
                                         @RequestBody @Valid MergeCartRequest req) {
        Long uid = resolveUserId(userId);
        if (uid == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(cart.merge(uid, req));
    }
}
