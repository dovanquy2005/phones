package com.fonestore.user_api.dto.cart;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record MergeCartRequest(
        @NotEmpty List<Item> items
) {
    public record Item(
            @NotNull Long skuId,
            @NotNull Integer qty
    ) {}
}