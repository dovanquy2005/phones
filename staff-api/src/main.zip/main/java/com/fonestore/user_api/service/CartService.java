package com.fonestore.user_api.service;

import com.fonestore.staff_api.entity.ProductVariant;
import com.fonestore.staff_api.repository.product.ProductVariantRepository;
import com.fonestore.user_api.dto.cart.*;
import com.fonestore.user_api.entity.Order;
import com.fonestore.user_api.entity.OrderItem;
import com.fonestore.user_api.repository.OrderItemRepository;
import com.fonestore.user_api.repository.OrderRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;

import java.util.Objects;

@Service
@RequiredArgsConstructor
public class CartService {

    private static final BigDecimal ZERO = BigDecimal.ZERO;

    private final OrderRepository orderRepo;
    private final OrderItemRepository itemRepo;
    private final ProductVariantRepository variantRepo;

    /* ======= Public APIs using userId (no auth in this module) ======= */

    @Transactional
    public CartDTO getCart(Long userId) {
        Order draft = getOrCreateDraft(userId);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO addItem(Long userId, AddItemRequest req) {
        if (req.qty() == null || req.qty() <= 0) {
            throw new IllegalArgumentException("qty must be > 0");
        }
        Order draft = getOrCreateDraft(userId);

        ProductVariant v = variantRepo.findById(req.skuId())
                .orElseThrow(() -> new IllegalArgumentException("SKU not found"));

        // Có thể chặn nếu SKU inactive
        if (Boolean.FALSE.equals(v.getIsActive())) {
            throw new IllegalArgumentException("SKU is inactive");
        }

        OrderItem item = itemRepo.findByOrder_IdAndSkuId(draft.getId(), v.getId())
                .orElseGet(() -> {
                    OrderItem ni = new OrderItem();
                    ni.setOrder(draft);
                    ni.setSkuId(v.getId());
                    ni.setQuantity(0);
                    // snapshot price từ list_price (Long) -> BigDecimal
                    ni.setUnitPrice(longToMoney(v.getListPrice()));
                    return ni;
                });

        int newQty = item.getQuantity() + req.qty();
        if (newQty <= 0) throw new IllegalArgumentException("qty must be > 0");

        item.setQuantity(newQty);
        itemRepo.save(item);

        recalc(draft);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO updateItem(Long userId, UpdateItemRequest req) {
        Order draft = requireDraft(userId);
        OrderItem it = itemRepo.findById(req.itemId())
                .orElseThrow(() -> new IllegalArgumentException("Item not found"));
        if (!Objects.equals(it.getOrder().getId(), draft.getId())) {
            throw new IllegalArgumentException("Item not in current cart");
        }

        if (req.qty() == null) throw new IllegalArgumentException("Missing qty");
        if (req.qty() <= 0) {
            itemRepo.delete(it);
        } else {
            // Nếu muốn thêm rào inactive/validate SKU:
            variantRepo.findById(it.getSkuId())
                    .orElseThrow(() -> new IllegalArgumentException("SKU not found"));
            it.setQuantity(req.qty());
            // giữ nguyên unitPrice (snapshot lúc thêm)
            itemRepo.save(it);
        }
        recalc(draft);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO removeItem(Long userId, Long itemId) {
        Order draft = requireDraft(userId);
        OrderItem it = itemRepo.findById(itemId)
                .orElseThrow(() -> new IllegalArgumentException("Item not found"));

        if (!Objects.equals(it.getOrder().getId(), draft.getId())) {
            throw new IllegalArgumentException("Item not in current cart");
        }
        itemRepo.delete(it);
        recalc(draft);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO clear(Long userId) {
        Order draft = requireDraft(userId);
        itemRepo.deleteByOrder_Id(draft.getId());
        draft.setSubtotal(ZERO);
        draft.setDiscount(nullToZero(draft.getDiscount()));
        draft.setShippingFee(nullToZero(draft.getShippingFee()));
        draft.setTotal(calcTotal(draft.getSubtotal(), draft.getDiscount(), draft.getShippingFee()));
        draft.setUpdatedAt(Instant.now());
        orderRepo.save(draft);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO checkout(Long userId) {
        Order draft = requireDraft(userId);
        if (itemRepo.countByOrder_Id(draft.getId()) == 0) {
            throw new IllegalStateException("Cart is empty");
        }
        draft.setStatus("CREATED"); // khóa giỏ → tạo đơn
        draft.setUpdatedAt(Instant.now());
        orderRepo.save(draft);
        return toDTO(draft);
    }

    @Transactional
    public CartDTO merge(Long userId, MergeCartRequest req) {
        Order draft = getOrCreateDraft(userId);
        if (req.items() == null || req.items().isEmpty()) return toDTO(draft);

        for (MergeCartRequest.Item x : req.items()) {
            if (x == null || x.skuId() == null || x.qty() == null || x.qty() <= 0) continue;

            ProductVariant v = variantRepo.findById(x.skuId()).orElse(null);
            if (v == null || Boolean.FALSE.equals(v.getIsActive())) continue;

            OrderItem item = itemRepo.findByOrder_IdAndSkuId(draft.getId(), v.getId())
                    .orElseGet(() -> {
                        OrderItem ni = new OrderItem();
                        ni.setOrder(draft);
                        ni.setSkuId(v.getId());
                        ni.setQuantity(0);
                        ni.setUnitPrice(longToMoney(v.getListPrice()));
                        return ni;
                    });

            int newQty = item.getQuantity() + x.qty();
            if (newQty <= 0) continue;

            item.setQuantity(newQty);
            itemRepo.save(item);
        }
        recalc(draft);
        return toDTO(draft);
    }

    /* ======= internals ======= */

    private Order requireDraft(Long userId) {
        return orderRepo.findByUserIdAndStatus(userId, "DRAFT")
                .orElseThrow(() -> new IllegalStateException("No cart (DRAFT)"));
    }

    private Order getOrCreateDraft(Long userId) {
        return orderRepo.findByUserIdAndStatus(userId, "DRAFT")
                .orElseGet(() -> {
                    Order o = new Order();
                    o.setUserId(userId);
                    o.setStatus("DRAFT");
                    o.setSubtotal(ZERO);
                    o.setDiscount(ZERO);
                    o.setShippingFee(ZERO);
                    o.setTotal(ZERO);
                    o.setCreatedAt(Instant.now());
                    o.setUpdatedAt(Instant.now());
                    return orderRepo.save(o);
                });
    }

    private void recalc(Order o) {
        BigDecimal subtotal = itemRepo.sumLineTotal(o.getId());
        if (subtotal == null) subtotal = ZERO;
        o.setSubtotal(subtotal);
        o.setDiscount(nullToZero(o.getDiscount()));
        o.setShippingFee(nullToZero(o.getShippingFee()));
        o.setTotal(calcTotal(o.getSubtotal(), o.getDiscount(), o.getShippingFee()));
        o.setUpdatedAt(Instant.now());
        orderRepo.save(o);
    }

    private static BigDecimal nullToZero(BigDecimal x) {
        return x == null ? ZERO : x;
    }

    private static BigDecimal longToMoney(Long v) {
        return BigDecimal.valueOf(v == null ? 0L : v);
    }

    private static BigDecimal calcTotal(BigDecimal sub, BigDecimal disc, BigDecimal ship) {
        if (sub == null) sub = ZERO;
        if (disc == null) disc = ZERO;
        if (ship == null) ship = ZERO;
        return sub.subtract(disc).add(ship);
    }

 
// trong CartService
private CartDTO toDTO(Order o) {
    var rows = itemRepo.findLinesWithInfo(o.getId());

    var itemDTOs = rows.stream().map(r -> new CartItemDTO(
            r.getId(),
            r.getSkuId(),
            r.getQuantity(),
            nullToZero(r.getUnitPrice()),
            nullToZero(r.getUnitPrice()).multiply(java.math.BigDecimal.valueOf(r.getQuantity())),
            r.getProductName(),
            r.getImagePath()
    )).toList();

    return new CartDTO(
            o.getId(),
            o.getStatus(),
            nullToZero(o.getSubtotal()),
            nullToZero(o.getDiscount()),
            nullToZero(o.getShippingFee()),
            nullToZero(o.getTotal()),
            itemDTOs
    );
}

}
