package com.fonestore.user_api.repository;

import com.fonestore.user_api.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;                // NEW

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    // === giữ nguyên các method cũ ===
    List<OrderItem> findAllByOrder_Id(Long orderId);

    Optional<OrderItem> findByOrder_IdAndSkuId(Long orderId, Long skuId);

    long countByOrder_Id(Long orderId);

    void deleteByOrder_Id(Long orderId);

    @Query("select coalesce(sum(i.unitPrice * i.quantity), 0) from OrderItem i where i.order.id = :orderId")
    BigDecimal sumLineTotal(@Param("orderId") Long orderId);     // thêm @Param cho chắc

    // === NEW: trả về dòng giỏ có kèm tên & ảnh sản phẩm ===
    @Query(value = """
            select  i.order_item_id as id,
                    i.sku_id           as skuId,
                    i.qty              as quantity,
                    i.unit_price       as unitPrice,
                    coalesce(p.name, concat('SKU #', i.sku_id)) as productName,
                    -- lấy 1 ảnh đầu tiên (SQL Server)
                    (select top 1 pi.file_path
                    from product_images pi
                    where pi.product_id = p.product_id
                    order by pi.sort_order asc) as imagePath
            from order_items i
            left join product_variants v on v.sku_id     = i.sku_id
            left join products         p on p.product_id = v.product_id
            where i.order_id = :orderId
            order by i.order_item_id asc
            """, nativeQuery = true)
    List<CartLineRow> findLinesWithInfo(@Param("orderId") Long orderId);


}
