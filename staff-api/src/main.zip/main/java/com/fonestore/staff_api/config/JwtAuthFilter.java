package com.fonestore.staff_api.config;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;

/**
 * Improved JwtAuthFilter:
 * - Try to extract numeric user id from claims (id, userId, user_id)
 * - Set principal to Long (id) when possible so controllers that expect numeric principal work
 * - Put claims into authentication details for downstream use
 * - Add debug logging for easier troubleshooting
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final Logger log = LoggerFactory.getLogger(JwtAuthFilter.class);

    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain)
            throws ServletException, IOException {

        final String path = req.getServletPath();

        // skip OPTIONS preflight
        if (HttpMethod.OPTIONS.matches(req.getMethod())) {
            chain.doFilter(req, res);
            return;
        }

        // skip public/static paths
        if (path.startsWith("/api/public/")
                || path.startsWith("/assets/")
                || path.startsWith("/user-frontend/")
                || path.startsWith("/staff-frontend/")
                || path.equals("/") || path.equals("/index.html")
                || path.equals("/favicon.ico")) {
            chain.doFilter(req, res);
            return;
        }

        String auth = req.getHeader("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            String token = auth.substring(7);
            try {
                Claims claims = jwtUtil.validateAndGetClaims(token);
                if (claims == null) {
                    log.debug("JwtAuthFilter: claims == null after validate");
                    chain.doFilter(req, res);
                    return;
                }

                // attempt to get numeric id from common claim keys
                Long userId = null;
                Object idClaim = null;
                List<String> tryKeys = Arrays.asList("id", "userId", "user_id");
                for (String k : tryKeys) {
                    idClaim = claims.get(k);
                    if (idClaim != null) break;
                }

                if (idClaim == null) {
                    // maybe stored as 'sub' or in subject; leave null for now
                } else {
                    try {
                        if (idClaim instanceof Number) {
                            userId = ((Number) idClaim).longValue();
                        } else {
                            String s = Objects.toString(idClaim, "");
                            userId = Long.parseLong(s);
                        }
                    } catch (NumberFormatException ex) {
                        log.debug("JwtAuthFilter: claim id not numeric: {} -> {}", idClaim, ex.getMessage());
                        userId = null;
                    }
                }

                // fallback: if subject is numeric, parse it
                String subject = claims.getSubject();
                if (userId == null && subject != null) {
                    try {
                        userId = Long.valueOf(subject);
                    } catch (NumberFormatException ignored) {
                        // subject not numeric — keep subject as username below
                    }
                }

                // roles handling (same as before)
                List<String> roles = new ArrayList<>();
                String role = claims.get("role", String.class);
                if (role != null && !role.isBlank()) {
                    roles.add(role.trim());
                } else {
                    @SuppressWarnings("unchecked")
                    List<String> arr = claims.get("roles", List.class);
                    if (arr != null) {
                        for (Object x : arr) {
                            if (x != null) roles.add(Objects.toString(x).trim());
                        }
                    }
                }
                if (roles.isEmpty()) {
                    roles.add("user");
                }

                // build authorities
                var authorities = roles.stream()
                        .filter(s -> s != null && !s.isBlank())
                        .map(SimpleGrantedAuthority::new)
                        .toList();

                // choose principal object: prefer Long userId if available, else subject string
                Object principalObj = userId != null ? userId : (subject != null ? subject : "anonymous");

                // create authentication and attach claims as details
                var authentication = new UsernamePasswordAuthenticationToken(
                        principalObj, null, authorities
                );
                Map<String, Object> details = new HashMap<>();
                // copy useful claims into details for downstream code (avoid storing entire Claims impl)
                details.put("claims", claims);
                if (subject != null) details.put("sub", subject);
                if (userId != null) details.put("userId", userId);
                authentication.setDetails(details);

                SecurityContextHolder.getContext().setAuthentication(authentication);
                log.debug("JwtAuthFilter: set Authentication principal={} name={} authorities={}",
                        principalObj, authentication.getName(), authorities);

            } catch (Exception ex) {
                // token invalid/expired -> log for debugging, do not throw to let security handle 401
                log.debug("JwtAuthFilter: token validation failed: {}", ex.getMessage());
            }
        }

        chain.doFilter(req, res);
    }
}
