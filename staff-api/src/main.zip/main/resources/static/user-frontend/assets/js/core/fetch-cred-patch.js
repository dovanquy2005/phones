// fetch-cred-patch.js
// Make fetch default to sending credentials unless caller explicitly sets them.
// Safe: handles string URL or Request object, and preserves explicit credentials.
(function () {
  const _fetch = window.fetch.bind(window);

  window.fetch = function (input, init) {
    // Normalize init to an object we can modify.
    init = init ? Object.assign({}, init) : {};

    // If credentials explicitly provided (even null), don't override.
    if (!('credentials' in init)) {
      init.credentials = 'include'; // change to 'same-origin' if you prefer
    }

    // If caller passed a Request object, construct a new Request merging init.
    if (input instanceof Request) {
      // Create a new Request that preserves original request but applies our init overrides.
      // Note: Request's body can only be used once; creating a new Request from an existing one
      // will reuse the body stream if it's still available.
      const merged = new Request(input, init);
      return _fetch(merged);
    }

    // Otherwise, input is URL string — call original fetch with the (possibly modified) init.
    return _fetch(input, init);
  };
})();
