package com.fonestore.staff_api.repository.order;

import com.fonestore.user_api.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StaffOrderItemRepository extends JpaRepository<OrderItem, Long> {
  List<OrderItem> findByOrderIdOrderByIdAsc(Long orderId);
}
