package com.fonestore.user_api.dto;

import java.math.BigDecimal;

import com.fonestore.staff_api.entity.enums.PaymentStatus;

public record PaymentDTO(
        Long paymentId,
        String method,
        BigDecimal amount,
        PaymentStatus status,
        String txnRef,
        java.time.LocalDateTime createdAt
) {}
