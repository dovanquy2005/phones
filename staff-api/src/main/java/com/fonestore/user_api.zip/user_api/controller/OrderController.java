package com.fonestore.user_api.controller;


import com.fonestore.user_api.dto.order.PagedOrderResponse;
import com.fonestore.user_api.service.OrderService;
import com.fonestore.user_api.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final SecurityUtil securityUtil;

    /**
     * GET /api/orders?page=0&size=10&status=DONE
     */
    @GetMapping
    public ResponseEntity<PagedOrderResponse> listOrders(@RequestParam(defaultValue = "0") int page,
                                                         @RequestParam(defaultValue = "10") int size,
                                                         @RequestParam(required = false) String status,
                                                         @RequestParam(required = false) Long userIdParam) {
        Long uid = securityUtil.resolveUserId(userIdParam);
        if (uid == null) return ResponseEntity.status(401).build();
        var res = orderService.listOrdersForUser(uid, page, size, status);
        return ResponseEntity.ok(res);
    }

    /**=
     * GET /api/orders/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<com.fonestore.staff_api.dto.order.OrderDetailDTO> getOrder(@PathVariable Long id,
                                                   @RequestParam(required = false) Long userIdParam) {
        Long uid = securityUtil.resolveUserId(userIdParam);
        if (uid == null) return ResponseEntity.status(401).build();
        var dto = orderService.getOrderDetail(uid, id);
        if (dto == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(dto);
    }
}
